package org.example.server.ClientBankA.controller;

import com.example.bankA.dto.BankTransactionRequest;
import com.example.bankA.dto.BankTransactionResponse;
import com.example.bankA.service.ServerForwarder;
import com.example.bankA.service.XmlConverter;
import com.example.bankA.util.TransactionIdGenerator;
import com.example.bankA.xml.TransactionRequestXml;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.OffsetDateTime;

@RestController
@RequestMapping("/bank")
public class BankTransactionController {

    private final TransactionIdGenerator idGenerator;
    private final XmlConverter xmlConverter;
    private final ServerForwarder serverForwarder;

    public BankTransactionController(TransactionIdGenerator idGenerator,
                                     XmlConverter xmlConverter,
                                     ServerForwarder serverForwarder) {
        this.idGenerator = idGenerator;
        this.xmlConverter = xmlConverter;
        this.serverForwarder = serverForwarder;
    }

    @PostMapping("/transaction")
    public ResponseEntity<BankTransactionResponse> handleTransaction(
            @RequestBody BankTransactionRequest request) {

        String trxId = idGenerator.nextId();

        TransactionRequestXml xmlRequest = new TransactionRequestXml();
        xmlRequest.setTrxId(trxId);
        xmlRequest.setBankId("BANK_A");
        xmlRequest.setCustomerId(request.getCustomerId());
        xmlRequest.setFromAccount(request.getFromAccount());
        xmlRequest.setToAccount(request.getToAccount());
        xmlRequest.setAmount(request.getAmount());
        xmlRequest.setCurrency(request.getCurrency());
        xmlRequest.setTimestamp(OffsetDateTime.now());

        String xml = xmlConverter.toXml(xmlRequest);

        // Asynchronous forwarding, non-blocking for this HTTP thread
        serverForwarder.forwardAsync(xml);

        BankTransactionResponse response =
                new BankTransactionResponse(trxId, "FORWARDED",
                        "Transaction forwarded to server");

        return ResponseEntity.accepted().body(response);
    }
}
