package org.example.server.service;

import com.example.server.dto.TransactionResponseDto;
import com.example.server.model.TransactionRequestXml;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;

@Service
public class TransactionOrchestratorService {

    private final XmlMapper xmlMapper;
    private final ExecutorService transactionExecutor;
    private final TransactionProcessingService processingService;

    public TransactionOrchestratorService(XmlMapper xmlMapper,
                                          ExecutorService transactionExecutor,
                                          TransactionProcessingService processingService) {
        this.xmlMapper = xmlMapper;
        this.transactionExecutor = transactionExecutor;
        this.processingService = processingService;
    }

    public CompletableFuture<TransactionResponseDto> processAsync(String xml) {
        long startTime = System.currentTimeMillis();

        return CompletableFuture.supplyAsync(() -> {
            TransactionRequestXml request;
            try {
                request = xmlMapper.readValue(xml, TransactionRequestXml.class);
            } catch (Exception e) {
                long time = System.currentTimeMillis() - startTime;
                return new TransactionResponseDto(null, "FAILED",
                        "Invalid XML format", time);
            }

            return processingService.process(request, startTime);
        }, transactionExecutor);
    }
}
