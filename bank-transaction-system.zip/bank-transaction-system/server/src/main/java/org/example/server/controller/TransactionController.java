package org.example.server.controller;

import com.example.server.dto.TransactionResponseDto;
import com.example.server.service.TransactionOrchestratorService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/server/transaction")
public class TransactionController {

    private final TransactionOrchestratorService orchestratorService;

    public TransactionController(TransactionOrchestratorService orchestratorService) {
        this.orchestratorService = orchestratorService;
    }

    @PostMapping(
            value = "/process",
            consumes = MediaType.APPLICATION_XML_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public CompletableFuture<TransactionResponseDto> process(@RequestBody String xml) {
        return orchestratorService.processAsync(xml);
    }
}
