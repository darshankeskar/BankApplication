package org.example.server.ClientBankB.controller;

import com.example.bankB.dto.BankTransactionRequest;
import com.example.bankB.dto.BankTransactionResponse;
import com.example.bankB.service.ServerForwarder;
import com.example.bankB.service.XmlConverter;
import com.example.bankB.util.TransactionIdGenerator;
import com.example.bankB.xml.TransactionRequestXml;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.OffsetDateTime;

/**
 * Bank B API:
 * POST /bank/transaction
 */
@RestController
@RequestMapping("/bank")
public class BankTransactionController {

    private final TransactionIdGenerator idGenerator;
    private final XmlConverter xmlConverter;
    private final ServerForwarder serverForwarder;

    public BankTransactionController(TransactionIdGenerator idGenerator,
                                     XmlConverter xmlConverter,
                                     ServerForwarder serverForwarder) {
        this.idGenerator = idGenerator;
        this.xmlConverter = xmlConverter;
        this.serverForwarder = serverForwarder;
    }

    @PostMapping("/transaction")
    public ResponseEntity<BankTransactionResponse> handleTransaction(
            @RequestBody BankTransactionRequest request) {

        // 1. Generate transaction ID
        String trxId = idGenerator.nextId();

        // 2. Map JSON -> XML model
        TransactionRequestXml xmlRequest = new TransactionRequestXml();
        xmlRequest.setTrxId(trxId);
        xmlRequest.setBankId("BANK_B");
        xmlRequest.setCustomerId(request.getCustomerId());
        xmlRequest.setFromAccount(request.getFromAccount());
        xmlRequest.setToAccount(request.getToAccount());
        xmlRequest.setAmount(request.getAmount());
        xmlRequest.setCurrency(request.getCurrency());
        xmlRequest.setTimestamp(OffsetDateTime.now());

        // 3. Convert to XML string
        String xml = xmlConverter.toXml(xmlRequest);

        // 4. Async forward to central server
        serverForwarder.forwardAsync(xml);

        // 5. Immediate response
        BankTransactionResponse response =
                new BankTransactionResponse(trxId, "FORWARDED",
                        "Transaction forwarded to server");

        return ResponseEntity.accepted().body(response);
    }
}
