package org.example.server.ClientBankB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankBClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(BankBClientApplication.class, args);
    }
}
