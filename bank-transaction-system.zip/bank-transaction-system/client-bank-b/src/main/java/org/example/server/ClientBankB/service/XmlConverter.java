package org.example.server.ClientBankB.service;


import com.example.bankB.xml.TransactionRequestXml;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.springframework.stereotype.Component;

@Component
public class XmlConverter {

    private final XmlMapper xmlMapper;

    public XmlConverter(XmlMapper xmlMapper) {
        this.xmlMapper = xmlMapper;
    }

    public String toXml(TransactionRequestXml request) {
        try {
            return xmlMapper.writeValueAsString(request);
        } catch (Exception e) {
            throw new RuntimeException("Error converting to XML", e);
        }
    }
}
